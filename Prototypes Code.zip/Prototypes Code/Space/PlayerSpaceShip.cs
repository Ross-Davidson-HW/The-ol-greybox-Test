using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpaceShip : MonoBehaviour
{
    Rigidbody spaceshipRB;

    //inputs
    float verticalMove;
    float horizontalMove;
    float mouseinputX;
    float mouseinputY;
    float roll;

    //speed multipliers
    [SerializeField]
    float speedMultiplier = 1;
    [SerializeField]
    float speedMultAngle = 0.5f;
    [SerializeField]
    float speedRollMultAngle = 0.05f;
    //called at the start of the program
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        spaceshipRB = GetComponent<Rigidbody>();
    }
    //called once per frame
    void Update()
    {
        verticalMove = Input.GetAxis("Vertical");
        horizontalMove = Input.GetAxis("Horizontal");
        roll = Input.GetAxis("Roll");

        mouseinputX = Input.GetAxis("Mouse X");
        mouseinputY = Input.GetAxis("Mouse Y");
    }
    //called every fixed frame
    void FixedUpdate()
    {
        spaceshipRB.AddForce(spaceshipRB.transform.TransformDirection(-Vector3.forward) * verticalMove * speedMultiplier, ForceMode.VelocityChange);

        spaceshipRB.AddForce(spaceshipRB.transform.TransformDirection(-Vector3.right) * horizontalMove * speedMultiplier, ForceMode.VelocityChange);

        spaceshipRB.AddTorque(spaceshipRB.transform.right * speedMultAngle * -mouseinputY * -1, ForceMode.VelocityChange);
        spaceshipRB.AddTorque(spaceshipRB.transform.up * speedMultAngle * -mouseinputX * -1, ForceMode.VelocityChange);

        spaceshipRB.AddTorque(spaceshipRB.transform.forward * speedRollMultAngle * -roll, ForceMode.VelocityChange);
    }
}