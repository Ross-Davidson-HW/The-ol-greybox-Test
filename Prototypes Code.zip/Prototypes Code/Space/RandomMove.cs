using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMove : MonoBehaviour
{
    public float minSpinSpeed = 1.0f;
    public float maxSpinSpeed = 5.0f;
    public float minMoveSpeed = 0.1f;
    public float maxMoveSpeed = 0.5f;
    private float spinSpeed;
    private float moveSpeed;
    // Start is called before the first frame update
    void Start()
    {
        spinSpeed = Random.Range(minSpinSpeed, maxSpinSpeed);
        moveSpeed = Random.Range(minMoveSpeed, maxMoveSpeed);

        Rigidbody rb = GetComponent<Rigidbody>();
        rb.AddForce(transform.forward * moveSpeed, ForceMode.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.up, spinSpeed * Time.deltaTime);
    }
}
