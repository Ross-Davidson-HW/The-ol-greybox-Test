using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class laserShot : MonoBehaviour
{
    public float fireRate;
    private float fRTimeStamp;

    public GameObject laserPrefab;

    RaycastHit hit;
    float range = 10000.0f;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            if (Time.time > fRTimeStamp)
            {
                laserShoot();
                fRTimeStamp = Time.time + fireRate;
            }
        }
    }

    void laserShoot()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(ray, out hit, range))
        {
            GameObject laser = GameObject.Instantiate(laserPrefab, transform.position,transform.rotation) as GameObject;
            laser.GetComponent<ShotBehaviour>().setTarget(hit.point);
            GameObject.Destroy(laser,2f);
        }
    }

   
}
