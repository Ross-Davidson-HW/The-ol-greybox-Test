using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotBehaviour : MonoBehaviour
{
    public Vector3 r_target;
    public GameObject collisionExplostion;
    public float speed;

    // Update is called once per frame
    void Update()
    {
        float step = speed * Time.deltaTime;

        if(r_target != null)
        {
            if(transform.position == r_target)
            {
                explode();
                return;
            }

            transform.position = Vector3.MoveTowards(transform.position, r_target, step);
        }
    }

    public void setTarget(Vector3 target)
    {

        r_target= target;
    }

    void explode()
    {
        if (collisionExplostion != null)
        {
            GameObject explosion = (GameObject)Instantiate(collisionExplostion, transform.position, transform.rotation);
            Destroy(gameObject);
            Destroy(explosion, 1f);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Enemy")
        {
            Destroy(collision.gameObject);
        }
    }
}
