using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidFieldGenerate : MonoBehaviour
{
    List<Transform> prefabList = new List<Transform>();
    public Transform astPrefab1;
    public Transform astPrefab2;
    public Transform astPrefab3;
    public Transform field;
    [SerializeField]
    public int fRadius = 100;
    [SerializeField]
    public int astCount = 500;

    // Start is called before the first frame update
    void Start()
    {
        prefabList.Add(astPrefab1);
        prefabList.Add(astPrefab2);
        prefabList.Add(astPrefab3);

        for (int i = 0; i < astCount; i++)
        {
            int prefabIndex = UnityEngine.Random.Range(0, 3);
            Transform asteroids = Instantiate(prefabList[prefabIndex], Random.insideUnitSphere * fRadius, Random.rotation);
            asteroids.transform.SetParent(field);
            asteroids.localScale = asteroids.localScale * Random.Range(0.5f, 3);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }
}
